<?php
// Роутер для справочной информации
function route($method, $urlData, $formData) {
    header('Content-Type: application/json');

    // Получение информации о конкретном типе объектов
    // GET /glossary/{type}/get
    if ($method === 'GET' && count($urlData) === 2) {
        $typeName = $urlData[0];
        $result = getGlossaryData($typeName);
        echo json_encode($result);
        return;
    }

    // Редактирование
    // POST /glossary/{type}/edit
    if ($method === 'POST' && count($urlData) === 2 && $urlData[1] == 'edit') {
        $typeName = $urlData[0];
        $result = editGlossaryData($typeName, $formData);
        echo json_encode([
            "success" => true,
        ]);
        return;
    }
    // Добавление
    // POST /glossary/{type}/add
    if ($method === 'POST' && count($urlData) === 2 && $urlData[1] == 'add') {
        $typeName = $urlData[0];
        $result = addGlossaryData($typeName, $formData);
        echo json_encode([
            "success" => true,
        ]);
        return;
    }

    // Возвращаем ошибку
    header('HTTP/1.0 400 Bad Request');
    echo json_encode(array(
        'error' => 'У нас нет такого запроса. Проверьте УРЛ.'
    ));
}
