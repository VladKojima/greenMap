<?php
// Универсальный метод получения справочных данных
function getGlossaryData($tableName) {
    $stmt = Connection::get()->query('SELECT * FROM `'.$tableName.'` ORDER BY "name" ASC;');
    $result = [];
    while($rows = $stmt->fetchAll(PDO::FETCH_ASSOC)) {
        for ($i = 0; $i < count($rows); $i++) {
            $row = $rows[$i];
            $result[$i] = $row;
        }
    }
    return $result;
}

function editGlossaryData($tableName, $data) {
    $sql = "UPDATE `".$tableName."` SET name = '".$data['name']."' WHERE id = ".$data['id'];
    writeToServerLog($sql);
    $stmt = Connection::get()->query($sql);
    while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        var_dump($row);
    }
}

function addGlossaryData($tableName, $data) {
    $sql = "INSERT INTO `".$tableName."` (`name`) VALUES('".$data['name']."')";
    writeToServerLog($sql);
    $stmt = Connection::get()->query($sql);
    while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        var_dump($row);
    }
}