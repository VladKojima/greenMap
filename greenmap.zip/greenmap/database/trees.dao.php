<?php 
/* new file ! 
    здесь запросы, связанные с деревьями - добавление, изменение, список 
*/

// Получить список деревьев по площадке
function getTreesInLocation($location_id) {
    $sql = "SELECT t.`id`, `id_location`, `tree_number`, `id_species`, `latitude`, `longitude`, `height`, `tdiameter`, `cdiameter`, `dry`, `detachment`, `cracks`, `drips`, `tilt`, `overhanging_t`, `overhanging_p`, `overhanging_comments`, `overhanging_d`, `archive`, t.`photo`, a.name as 'name_location', s.name as 'name_species' FROM `trees` AS t JOIN locations AS a ON id_location = a.id JOIN species AS s ON id_species = s.id WHERE archive = 0 AND id_location = " . $location_id;
    $stmt = Connection::get()->query($sql);

    $result = [];
    while($rows = $stmt->fetchAll(PDO::FETCH_ASSOC)) {
        for ($i = 0; $i < count($rows); $i++) {
            $row = $rows[$i];
            $result[$i] = $row;
        }
    }
    return $result;
}


// Добавить дерево
function addTree($data, $img) {
    $sql_new = "INSERT INTO `trees` (`id_location`, `tree_number`, `id_species`, `latitude`, `longitude`, `height`, `tdiameter`, `cdiameter`, `dry`, `detachment`, `cracks`, `drips`, `tilt`, `overhanging_t`, `overhanging_p`, `overhanging_d`, `photo`) VALUES (".$data['id_location'].", 1, ".$data['id_species'].", ".$data['coordinates'][0].", ".$data['coordinates'][1].", ".$data['height'].", ".$data['tdiameter'].", ".$data['cdiameter'].", ".$data['dry'].", ".$data['detachment'].", ".$data['cracks'].", ".$data['drips'].", ".$data['tilt'].", ".$data['overhanging_t'].", ".$data['overhanging_p'].", ".$data['overhanging_d'].", '".$img."');";
    writeToServerLog($sql_new);
    $stmt = Connection::get()->query($sql_new);
    if (!is_null($data['overhanging_comments'])) {
        $sql2 = "SELECT `id` FROM `trees` ORDER BY `id` DESC LIMIT 1";
        $stmt2 = Connection::get()->query($sql2);
        while($row = $stmt2->fetch(PDO::FETCH_ASSOC)) {
            var_dump($row);
            $id = $row['id'];
        }
        $tree = getTreeById($id);
        $sql2 = "UPDATE `trees` SET `overhanging_comments` = '".$data['overhanging_comments']."' WHERE `id` = ".$id;
        $stmt3 = Connection::get()->query($sql2);
        var_dump($stmt3);
    }

    return $stmt;
}

// Фильтрация
function filterTrees($data) {

}

// Архивация
function archiveTree($tree_id, $archive) {
    $sql = "UPDATE trees SET `archive`=".$archive." WHERE id = ".$tree_id;
    writeToServerLog($sql);
    $stmt = Connection::get()->query($sql);
    while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        var_dump($row);
    }
}

// перемещение дерева
function moveTree($tree_id, $lat, $long) {
    $sql = "UPDATE trees SET `latitude`=".$lat.", `longitude`=".$long." WHERE id = ".$tree_id;
    writeToServerLog($sql);
    $stmt = Connection::get()->query($sql);
    while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        var_dump($row);
    }
}


// Изменение картинки дерева 
function changeImageOfTree($tree_id, $img) {
    $sql = "UPDATE `trees` SET `photo`='".$img."' WHERE id = ".$tree_id;
    writeToServerLog($sql);
    $stmt = Connection::get()->query($sql);
    while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        var_dump($row);
    }
}

// другие изменения
function editTree($data) {
    $sql = "UPDATE `trees` SET `id_species`=".$data['id_species'].",`latitude`=".$data['coordinates'][0].",`longitude`=".$data['coordinates'][1].",`height`=".$data['height'].",`tdiameter`=".$data['tdiameter'].",`cdiameter`=".$data['cdiameter'].",`dry`=".$data['dry'].",`detachment`=".$data['detachment'].",`cracks`=".$data['cracks'].",`drips`=".$data['drips'].",`tilt`=".$data['tilt'].",`overhanging_t`=".$data['overhanging_t'].",`overhanging_p`=".$data['overhanging_p'].",`overhanging_d`=".$data['overhanging_d']." WHERE id=".$data['tree_id'];
    writeToServerLog($sql);
    $stmt = Connection::get()->query($sql);
    while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        var_dump($row);
    }
    if (isset($data['overhanging_comments']) && !is_null($data['overhanging_comments'])) {
        $sql = "UPDATE `trees` SET `overhanging_comments`='".$data['overhanging_comments']."' WHERE id=".$data['tree_id'];
    }
    else if (is_null($data['overhanging_comments'])) {
        $sql = "UPDATE `trees` SET `overhanging_comments`= NULL WHERE id=".$data['tree_id'];
    }
    
    $stmt = Connection::get()->query($sql);
    // return $sql;
}

function getTreeById($id) {
    echo $id;
    $sql = "SELECT t.`id`, `id_location`, `tree_number`, `latitude`, `longitude`, `height`, `tdiameter`, `cdiameter`, `dry`, `detachment`, `cracks`, `drips`, `tilt`, `overhanging_t`, `overhanging_p`, `overhanging_comments`, `overhanging_d`, `archive`, t.`photo`, a.name as 'name_location', s.name as 'name_species' FROM `trees` AS t JOIN locations AS a ON id_location = a.id JOIN species AS s ON id_species = s.id WHERE t.id =" . $id;
    echo $sql;
    $stmt = Connection::get()->query($sql);

    $result = [];
    while($rows = $stmt->fetchAll(PDO::FETCH_ASSOC)) {
        for ($i = 0; $i < count($rows); $i++) {
            $row = $rows[$i];
            $result[$i] = $row;
        }
    }
    return $result;
}

function getSpeciesByName($name) {
    $stmt = Connection::get()->query('SELECT * FROM `species` WHERE name = "'.$name.'"');
    $result = [];
    while($rows = $stmt->fetchAll(PDO::FETCH_ASSOC)) {
        for ($i = 0; $i < count($rows); $i++) {
            $row = $rows[$i];
            $result[$i] = $row;
        }
    }
    return $result;
}

// function addGlossaryData($tableName, $data) {
//     $sql = "INSERT INTO `".$tableName."` (`name`) VALUES('".$data['name']."')";
//     writeToServerLog($sql);
//     $stmt = Connection::get()->query($sql);
//     while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
//         var_dump($row);
//     }
// }

function addFewTrees() {
    
}
?>